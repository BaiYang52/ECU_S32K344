package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;
import javax.jmi.model.*;

/**
 * Reliability against data loss on the non-volatile medium.
 * These requirements give only a relative indication, for example on the required degree of redundancy
 * for storage. They do however not specify by which means (e.g. software or hardware) the reliability
 * is actually achieved.
 */
public enum MINvBlockNeedsReliabilityEnum implements javax.jmi.reflect.RefEnum
{
  LOW("LOW"),
  MEDIUM("MEDIUM"),
  HIGH("HIGH");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "serviceneeds" );
    temp.add( "NvBlockNeedsReliabilityEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MINvBlockNeedsReliabilityEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
