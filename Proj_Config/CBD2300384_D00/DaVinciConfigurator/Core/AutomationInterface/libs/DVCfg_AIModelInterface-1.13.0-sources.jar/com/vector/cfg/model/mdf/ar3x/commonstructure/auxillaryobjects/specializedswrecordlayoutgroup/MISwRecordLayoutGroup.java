package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.specializedswrecordlayoutgroup;

public interface MISwRecordLayoutGroup extends com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup, com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild
{
  public final static String CLASS_NAME = "SwRecordLayoutGroup";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwRecordLayoutGroup> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwRecordLayoutGroup> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
