package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

/**
 * No filtering is performed so that the message always passes.
 */
public interface MIAlways extends com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter
{
  public final static String CLASS_NAME = "Always";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIAlways> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIAlways> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
