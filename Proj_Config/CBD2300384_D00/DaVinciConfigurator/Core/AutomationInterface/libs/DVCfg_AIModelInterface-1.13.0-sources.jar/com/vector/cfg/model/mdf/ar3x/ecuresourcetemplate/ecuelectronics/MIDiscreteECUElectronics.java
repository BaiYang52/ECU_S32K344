package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

public interface MIDiscreteECUElectronics extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIECUElectronics
{
  public final static String CLASS_NAME = "DiscreteECUElectronics";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDiscreteECUElectronics> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIDiscreteECUElectronics> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
