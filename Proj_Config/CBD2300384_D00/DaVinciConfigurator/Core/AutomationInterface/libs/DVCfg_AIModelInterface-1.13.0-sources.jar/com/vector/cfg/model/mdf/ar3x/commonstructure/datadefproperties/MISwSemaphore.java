package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

/**
 * This element denotes a variable which servers as a semaphore for a particular resource which is specified in the surrounding data object, e.g. SwDataDefProps.
 */
public interface MISwSemaphore extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRefSwVariableRefProxy
{
  public final static String CLASS_NAME = "SwSemaphore";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwSemaphore> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwSemaphore> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
