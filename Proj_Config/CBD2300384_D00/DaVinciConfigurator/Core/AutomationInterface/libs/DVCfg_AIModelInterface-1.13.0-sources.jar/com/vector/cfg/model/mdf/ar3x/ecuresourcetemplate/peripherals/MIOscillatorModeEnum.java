package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

/**
 * Crystals and other oscillating elements have more than one resonant frequencies, which are
 * usually odd harmonics to the basic, fundamental frequencies. For Automotive a basic requirement
 * should be to use only fundamental mode only. Using overtone modes there is a risk, that the
 * oscillator circuitry starts at the fundamental mode after a error in the start up routine.
 * In order to reach an overtone mode the frequency of the fundamental mode, or lower overtones
 * has to be passed during start up. There is a risk that the oscillator locks to this, lower
 * frequency. Therefore Fundamental modes oscillatorts are not so critical for this issue. Fundamental
 * quartz/crystals can reach up to 40 MHz today, above this frequency all quartz/crystals are
 * running in the 3rd, 5th or higher overtone mode.
 */
public enum MIOscillatorModeEnum implements javax.jmi.reflect.RefEnum
{
  FUNDAMENTAL("FUNDAMENTAL"),
  OVERTONE("OVERTONE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "OscillatorModeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIOscillatorModeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
