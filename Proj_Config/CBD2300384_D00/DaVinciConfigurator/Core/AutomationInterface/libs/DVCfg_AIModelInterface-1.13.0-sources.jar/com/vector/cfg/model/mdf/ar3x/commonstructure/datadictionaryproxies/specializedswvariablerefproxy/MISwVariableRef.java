package com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.specializedswvariablerefproxy;

public interface MISwVariableRef extends com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgsChild, com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy
{
  public final static String CLASS_NAME = "SwVariableRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwVariableRef> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwVariableRef> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
