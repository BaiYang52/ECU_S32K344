package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

/**
 * There are several addressing modes possible. Typical attributes are:
 * - Direct
 * - Indirect
 * - Absolute
 * - Base + offset (relative)
 * - Near / far
 * - Pre/Post- Increment/decrement
 * The addressing modes take important influence to the performance index of a PU, but are not
 * main topic of the software development, as far as high level programming languages are used,
 * due to the fact that these are covered by compiler settings and compiler strategies. The main
 * advantage is available at the level of assembler programming or compiler optimization.
 * The Enumeration is open.
 */
public enum MIProcessingUnitAdressingModeEnum implements javax.jmi.reflect.RefEnum
{
  DIRECT("DIRECT"),
  INDIRECT("INDIRECT"),
  INDEXED("INDEXED");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "ProcessingUnitAdressingModeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIProcessingUnitAdressingModeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
