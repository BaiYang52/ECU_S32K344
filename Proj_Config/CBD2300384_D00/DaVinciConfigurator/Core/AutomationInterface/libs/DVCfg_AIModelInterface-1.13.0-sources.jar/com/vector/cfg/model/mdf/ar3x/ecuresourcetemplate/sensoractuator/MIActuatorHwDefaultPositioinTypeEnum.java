package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;
import javax.jmi.model.*;

/**
 * Defines the way the actuator is seen after power on. On Bi-Stable or Multistable actuators
 * the software has to know the status of this device after reset or Power On.
 * Each actuator has a control input that determines its behaviour
 */
public enum MIActuatorHwDefaultPositioinTypeEnum implements javax.jmi.reflect.RefEnum
{
  STABLE("STABLE"),
  INSTABLE("INSTABLE"),
  BI_STABLE("BI-STABLE"),
  MULTI_STABLE("MULTI-STABLE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "sensoractuator" );
    temp.add( "ActuatorHwDefaultPositioinTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIActuatorHwDefaultPositioinTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
