package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;
import javax.jmi.model.*;

/**
 * Programming language the implementation was created in.
 */
public enum MIProgramminglanguageEnum implements javax.jmi.reflect.RefEnum
{
  C("C"),
  CPP("CPP"),
  JAVA("JAVA");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "implementation" );
    temp.add( "ProgramminglanguageEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIProgramminglanguageEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
