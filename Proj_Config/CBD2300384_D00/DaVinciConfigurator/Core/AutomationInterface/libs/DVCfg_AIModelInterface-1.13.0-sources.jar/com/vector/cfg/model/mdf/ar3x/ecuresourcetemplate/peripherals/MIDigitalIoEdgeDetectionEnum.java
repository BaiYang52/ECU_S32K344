package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

/**
 * A general digital input can be enabled to trigger an interrupt on a falling, rising or both
 * edges of an input signal. A clock, compare or count input on a timer can be programmed to increase,
 * decrease or store the timer value if a change on the input pin has occurred. The condition
 * for this change can be programmed to trigger an event  in the same manner as for a digital input.
 */
public enum MIDigitalIoEdgeDetectionEnum implements javax.jmi.reflect.RefEnum
{
  RISING("RISING"),
  FALLING("FALLING"),
  RAISING_FALLING("RAISING-FALLING");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "DigitalIoEdgeDetectionEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIDigitalIoEdgeDetectionEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
