package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;
import javax.jmi.model.*;

public enum MICompuMethodTypesEnum implements javax.jmi.reflect.RefEnum
{
  COMPU_METHOD("COMPU-METHOD");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "computationmethod" );
    temp.add( "CompuMethodTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MICompuMethodTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
