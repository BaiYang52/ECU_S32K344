package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

/**
 * Specifies the abstract needs on the configuration of the ECU State  Manager for one "user". This class currently contains no attributes. Its name can be regarded as a symbol identifying the user  from the viewpoint of the component or module which owns this class.
 */
public interface MIEcuStateMgrUserNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "EcuStateMgrUserNeeds";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIEcuStateMgrUserNeeds> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIEcuStateMgrUserNeeds> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
