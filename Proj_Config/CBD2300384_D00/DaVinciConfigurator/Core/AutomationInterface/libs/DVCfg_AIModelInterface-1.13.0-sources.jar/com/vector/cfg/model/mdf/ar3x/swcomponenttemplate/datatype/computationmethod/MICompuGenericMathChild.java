package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

public interface MICompuGenericMathChild extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIValueByFormulaChild
{
  public final static String CLASS_NAME = "CompuGenericMathChild";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompuGenericMathChild> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MICompuGenericMathChild> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
