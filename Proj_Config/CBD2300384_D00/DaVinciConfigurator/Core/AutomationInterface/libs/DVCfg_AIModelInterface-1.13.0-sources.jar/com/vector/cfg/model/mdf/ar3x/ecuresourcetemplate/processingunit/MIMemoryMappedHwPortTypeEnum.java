package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

/**
 * The type of an HW port
 */
public enum MIMemoryMappedHwPortTypeEnum implements javax.jmi.reflect.RefEnum
{
  UNSPECIFIED("UNSPECIFIED"),
  DATA("DATA"),
  CONTROL("CONTROL");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "MemoryMappedHwPortTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIMemoryMappedHwPortTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
