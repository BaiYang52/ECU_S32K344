package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

/**
 * The ApplicationSoftwareComponentType is used to represent the application software.
 */
public interface MIApplicationSoftwareComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType
{
  public final static String CLASS_NAME = "ApplicationSoftwareComponentType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIApplicationSoftwareComponentType> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIApplicationSoftwareComponentType> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
