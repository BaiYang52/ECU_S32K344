package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;
import javax.jmi.model.*;

/**
 * Enumeration describing the process steps a dependency is valid in.
 */
public enum MIDependencyUsageEnum implements javax.jmi.reflect.RefEnum
{
  COMPILE("COMPILE"),
  LINK("LINK"),
  BUILD("BUILD"),
  EXECUTE("EXECUTE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "implementation" );
    temp.add( "DependencyUsageEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIDependencyUsageEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
