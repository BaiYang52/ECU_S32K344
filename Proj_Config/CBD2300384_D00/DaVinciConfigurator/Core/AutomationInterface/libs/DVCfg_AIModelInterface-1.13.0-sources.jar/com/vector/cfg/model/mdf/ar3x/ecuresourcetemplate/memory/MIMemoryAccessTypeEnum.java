package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;
import javax.jmi.model.*;

/**
 * he element access type describes the different possible kinds of access to the memory.
 * Note: The access is denied during erasure and programming of Flash and EEPROM as some technologies
 * do not allow a simultaneous read access to that specific memory area.
 * Also during the simultaneous access of different subscribers on the same memory, array or byte
 * the access is either denied or at least delayed. For example if the CPU and the DMA write to
 * the same memory block.
 */
public enum MIMemoryAccessTypeEnum implements javax.jmi.reflect.RefEnum
{
  READ("READ"),
  WRITE("WRITE"),
  ERASE("ERASE"),
  PROGRAM("PROGRAM"),
  RANDOM("RANDOM"),
  SEQUENCE("SEQUENCE"),
  BURST("BURST");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "memory" );
    temp.add( "MemoryAccessTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIMemoryAccessTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
