package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

/**
 * The filter removes all messages.
 */
public interface MINever extends com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter
{
  public final static String CLASS_NAME = "Never";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MINever> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MINever> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
