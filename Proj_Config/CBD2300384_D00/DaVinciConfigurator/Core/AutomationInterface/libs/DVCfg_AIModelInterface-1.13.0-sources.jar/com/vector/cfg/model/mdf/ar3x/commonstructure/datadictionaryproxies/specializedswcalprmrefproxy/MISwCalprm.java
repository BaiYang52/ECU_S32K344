package com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.specializedswcalprmrefproxy;

public interface MISwCalprm extends com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwCalprmRefProxy, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgsChild
{
  public final static String CLASS_NAME = "SwCalprm";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwCalprm> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwCalprm> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
