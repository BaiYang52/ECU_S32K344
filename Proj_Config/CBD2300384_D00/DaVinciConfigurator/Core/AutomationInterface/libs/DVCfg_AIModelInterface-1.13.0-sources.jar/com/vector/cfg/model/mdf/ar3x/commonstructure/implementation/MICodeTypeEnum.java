package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;
import javax.jmi.model.*;

/**
 * The type of described code.
 */
public enum MICodeTypeEnum implements javax.jmi.reflect.RefEnum
{
  SRC("SRC"),
  OBJ("OBJ");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "implementation" );
    temp.add( "CodeTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MICodeTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
