package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

public interface MISwServicePrototype extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.ar3x.commonstructure.systemconstant.MIIsSyscond
{
  public final static String CLASS_NAME = "SwServicePrototype";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwServicePrototype> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwServicePrototype> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
