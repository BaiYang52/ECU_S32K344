package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;

public interface MIScaleConstrs extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIHasScaleConstr
{
  public final static String CLASS_NAME = "ScaleConstrs";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIScaleConstrs> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIScaleConstrs> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
