package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

public interface MITimerCountDirectionEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "TimerCountDirectionEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MITimerCountDirectionEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.ecuresourcetemplate.peripherals.TimerCountDirectionEnumItem",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerCountDirectionEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerCountDirectionEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerCountDirectionEnum newValue);
  public ru.novosoft.mdf.ext.ICloneResult<? extends MITimerCountDirectionEnumItem> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
