package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

public interface MICodeTypeEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "CodeTypeEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICodeTypeEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.commonstructure.implementation.CodeTypeEnumItem",null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICodeTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICodeTypeEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICodeTypeEnum newValue);
  public ru.novosoft.mdf.ext.ICloneResult<? extends MICodeTypeEnumItem> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
