package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask;

/**
 * tbd
 */
public interface MISwServiceImpl extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwServiceImpl";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwServiceImpl> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwServiceImpl> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
