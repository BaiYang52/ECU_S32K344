package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces;

public interface MIBswCallTypeItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "BswCallTypeItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswCallTypeItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.bswmoduletemplate.bswinterfaces.BswCallTypeItem",null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswCallType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswCallType getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswCallType newValue);
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIBswCallTypeItem> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
