package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

/**
 * Defines the object-oriented class-attributes: SW-VARIABLE-IMPLS which implement attributes that are variables, SW-CALPRM-IMPLS which implement attributes that are calibration parameters and SW-CLASS-IMPLS which implement attributes that are class instances themselves.
 */
public interface MISwClassAttrImpl extends com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwCalprmImpl, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps, com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwVariableImpl, com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "SwClassAttrImpl";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwClassAttrImpl> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwClassAttrImpl> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
