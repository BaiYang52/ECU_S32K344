package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

/**
 * This connection is used to delegate a Memory HW Port to the outside of a HW Container. Typically this will used internally of a micro-controller.
 */
public interface MIMemoryMappedDelegationHWConnection extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIDelegationHWConnection
{
  public final static String CLASS_NAME = "MemoryMappedDelegationHWConnection";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMemoryMappedDelegationHWConnection> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIMemoryMappedDelegationHWConnection> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
