package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.specializedswrecordlayoutarref;

public interface MIContentSwRecordLayoutARRef extends com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef, com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild
{
  public final static String CLASS_NAME = "ContentSwRecordLayoutARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIContentSwRecordLayoutARRef> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIContentSwRecordLayoutARRef> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
