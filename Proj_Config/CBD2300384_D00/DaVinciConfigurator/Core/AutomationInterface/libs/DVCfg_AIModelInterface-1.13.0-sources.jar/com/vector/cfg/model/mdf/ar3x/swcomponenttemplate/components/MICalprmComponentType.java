package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

public interface MICalprmComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType
{
  public final static String CLASS_NAME = "CalprmComponentType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICalprmComponentType> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MICalprmComponentType> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
