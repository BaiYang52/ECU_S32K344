package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

public interface MISignalFanEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "SignalFanEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISignalFanEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.swcomponenttemplate.applicationattributes.SignalFanEnumItem",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISignalFanEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISignalFanEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISignalFanEnum newValue);
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISignalFanEnumItem> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
