package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

public interface MINvBlockNeedsWritingPriorityEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "NvBlockNeedsWritingPriorityEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MINvBlockNeedsWritingPriorityEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.commonstructure.serviceneeds.NvBlockNeedsWritingPriorityEnumItem",null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsWritingPriorityEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsWritingPriorityEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsWritingPriorityEnum newValue);
  public ru.novosoft.mdf.ext.ICloneResult<? extends MINvBlockNeedsWritingPriorityEnumItem> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
