package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.specializedsdx;

public interface MISdx3x extends com.vector.cfg.model.mdf.model.autosar.commonpatterns.specialdata.MISdgContentsChild, com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdx
{
  public final static String CLASS_NAME = "Sdx3x";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISdx3x> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISdx3x> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
