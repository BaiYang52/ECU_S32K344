package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

/**
 * This meta-class represents the ability to define an initial value for a calibration parameter.
 */
public interface MIParameterRequireComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.componentlocalcalprm.MIInitValueAssignment, com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIRPortComSpec
{
  public final static String CLASS_NAME = "ParameterRequireComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIParameterRequireComSpec> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIParameterRequireComSpec> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
