package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces;

public interface MIBswExecutionContextItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "BswExecutionContextItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswExecutionContextItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.bswmoduletemplate.bswinterfaces.BswExecutionContextItem",null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswExecutionContext.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswExecutionContext getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswExecutionContext newValue);
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIBswExecutionContextItem> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
