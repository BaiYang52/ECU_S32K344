package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

/**
 * This meta-class represents the ability to provide an initial value for a calibration parameter.
 */
public interface MIParameterProvideComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.componentlocalcalprm.MIInitValueAssignment, com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec
{
  public final static String CLASS_NAME = "ParameterProvideComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIParameterProvideComSpec> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIParameterProvideComSpec> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
