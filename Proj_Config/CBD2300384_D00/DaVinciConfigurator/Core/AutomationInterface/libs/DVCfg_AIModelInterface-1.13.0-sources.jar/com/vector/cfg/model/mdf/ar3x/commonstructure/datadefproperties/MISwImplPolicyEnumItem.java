package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

public interface MISwImplPolicyEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "SwImplPolicyEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwImplPolicyEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.commonstructure.datadefproperties.SwImplPolicyEnumItem",null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwImplPolicyEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwImplPolicyEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwImplPolicyEnum newValue);
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwImplPolicyEnumItem> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
