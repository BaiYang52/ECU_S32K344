package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;
import javax.jmi.model.*;

/**
 * Specifies the implementation strategy with respect to consistency mechanisms of variables.
 */
public enum MISwImplPolicyEnum implements javax.jmi.reflect.RefEnum
{
  MEASUREMENT_POINT("MEASUREMENT-POINT"),
  STANDARD("STANDARD"),
  MESSAGE("MESSAGE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "datadefproperties" );
    temp.add( "SwImplPolicyEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwImplPolicyEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
