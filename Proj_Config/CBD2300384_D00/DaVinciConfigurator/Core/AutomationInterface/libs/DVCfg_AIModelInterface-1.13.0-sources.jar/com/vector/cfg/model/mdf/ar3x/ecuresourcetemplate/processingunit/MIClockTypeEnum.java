package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

/**
 * type creating clock signals
 */
public enum MIClockTypeEnum implements javax.jmi.reflect.RefEnum
{
  PLL("PLL"),
  DIVIDER("DIVIDER");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "ClockTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIClockTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
