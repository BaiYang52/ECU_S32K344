package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.specializedswrecordlayoutv;

public interface MISwRecordLayoutV extends com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild, com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutV
{
  public final static String CLASS_NAME = "SwRecordLayoutV";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwRecordLayoutV> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwRecordLayoutV> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
