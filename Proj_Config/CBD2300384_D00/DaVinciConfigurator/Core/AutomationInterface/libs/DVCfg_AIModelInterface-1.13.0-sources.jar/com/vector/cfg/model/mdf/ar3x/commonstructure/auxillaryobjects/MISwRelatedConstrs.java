package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;

/**
 * This element describes plausibility rules that go beyond the individual data object. E.g. the overrun shut-off engine speed must not be higher than the maximum engine speed. This plausibility rule is defined in exactly the same way as the contexts and dependencies of virtual characteristic variables and variables.
 */
public interface MISwRelatedConstrs extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwRelatedConstrs";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwRelatedConstrs> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MISwRelatedConstrs> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
