package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

public interface MIMemoryMappedHwPortTypeEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "MemoryMappedHwPortTypeEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMemoryMappedHwPortTypeEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.ecuresourcetemplate.processingunit.MemoryMappedHwPortTypeEnumItem",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMemoryMappedHwPortTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMemoryMappedHwPortTypeEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMemoryMappedHwPortTypeEnum newValue);
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIMemoryMappedHwPortTypeEnumItem> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
