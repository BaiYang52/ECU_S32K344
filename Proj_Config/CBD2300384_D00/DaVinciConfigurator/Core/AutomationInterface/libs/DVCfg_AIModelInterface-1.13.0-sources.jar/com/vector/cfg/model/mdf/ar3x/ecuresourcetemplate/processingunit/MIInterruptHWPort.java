package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

public interface MIInterruptHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort
{
  public final static String CLASS_NAME = "InterruptHWPort";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIInterruptHWPort> mdfGetClass();
  public ru.novosoft.mdf.ext.ICloneResult<? extends MIInterruptHWPort> mdfClone(aquintos.mdf.ICloneEnvironment environment);
}
