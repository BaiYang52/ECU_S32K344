package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

/**
 * The following attributes are opcodes, which are not supported by all PUs. The support of this
 * opcodes has an influence on the performance of the PU.
 * - Bit-manipulation
 * - Multiplication
 * - Division
 * - Multiply Accumulate
 * - Floating-point Support
 * In the future further opcodes may be possible.
 * The special opcodes  take important influence to the performance index of a PU, but are not
 * main topic of the software development, as far as high level programming languages are used,
 * due to the fact that these are covered by compiler settings, compiler strategies and software
 * libraries where the direct usage or a SW emulation is available for almost any general use
 * case. For some of these opcodes the main advantage is available only at the level of assembler
 * programming or compiler optimization.
 */
public enum MIProcessingUnitSpecialOpcodesEnum implements javax.jmi.reflect.RefEnum
{
  BIT_MANIPULATION("BIT-MANIPULATION"),
  MUL("MUL"),
  DIV("DIV"),
  MAC("MAC"),
  FLOAT("FLOAT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "ProcessingUnitSpecialOpcodesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIProcessingUnitSpecialOpcodesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
